#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define LEFT_CHILD(N) 2*N + 1
#define RIGHT_CHILD(N) 2*N + 2
#define PARENT(N) (N - 1) / 2
#define ROOT 0

#define MIN_HEAP lesser
#define MAX_HEAP greater

typedef struct {
	int value;
} ELEMENT;

typedef struct {
	ELEMENT **content;
	int size;
	int (*compare)(ELEMENT *, ELEMENT *);
} HEAP;

void swap(ELEMENT **v, int i, int j) {
	ELEMENT *aux = v[i];
	v[i] = v[j];
	v[j] = aux;
}

int lesser(ELEMENT *a, ELEMENT *b) {
	return a->value < b->value;
}

int greater(ELEMENT *a, ELEMENT *b) {
	return a->value > b->value;
}

HEAP *createHeap(int compare(ELEMENT *, ELEMENT *)) {
	HEAP *res = (HEAP *) malloc(sizeof(HEAP));
	res->size = 0;
	res->content = NULL;
	res->compare = compare;

	return res;
}

void down(HEAP *heap, int i) {
	if(i < heap->size) {
		int leftChild = LEFT_CHILD(i);
		int rightChild = RIGHT_CHILD(i);
		int change = i;

		if(leftChild < heap->size && heap->compare(heap->content[leftChild], heap->content[change]))
			change = leftChild;

		if(rightChild < heap->size && heap->compare(heap->content[rightChild], heap->content[change]))
			change = rightChild;

		if(change != i) {
			swap(heap->content, i, change);
			down(heap, change);
		}
	}
}

void up(HEAP *heap, int i) {
	if(i > 0 && i < heap->size) {
		int parent = PARENT(i);

		if(heap->compare(heap->content[i], heap->content[parent])) {
			swap(heap->content, i, parent);
			up(heap, parent);
		}
	}
}

void vectorHeapify(HEAP *h) {
	int i;

	for(i = pow(2, floor(log2(h->size))) - 1; i >= 0; i--)
		down(h, i);
}

void insertHeap(HEAP *heap, ELEMENT *element) {
	heap->content = (ELEMENT **) realloc(heap->content, sizeof(ELEMENT *) * (++(heap->size)));
	heap->content[heap->size - 1] = element;
	up(heap, heap->size - 1);
}

void insertVector(HEAP *heap, ELEMENT *element) {
	heap->content = (ELEMENT **) realloc(heap->content, sizeof(ELEMENT *) * (++(heap->size)));
	heap->content[heap->size - 1] = element;
}

ELEMENT *top(HEAP *heap) {
	if(heap->size > 0)
		return heap->content[ROOT];

	return NULL;
}

void pop(HEAP *heap) {
	if(heap->size > 0) {
		swap(heap->content, ROOT, heap->size - 1);
		heap->content = (ELEMENT **) realloc(heap->content, sizeof(ELEMENT *)*(--(heap->size)));

		down(heap, ROOT);
	}
}

void freeHeap(HEAP *heap) {
	free(heap->content);
	free(heap);
}

void printElement(ELEMENT *element) {
	printf("%d ", element->value);
}

void printHeap(HEAP *h) {
	int i;
	for (i = 0; i < h->size; i++)
		printElement(h->content[i]);
	printf("\n");
}

int main() {
	HEAP *h = createHeap(MIN_HEAP);
	ELEMENT *aux;
	int n;

	while(scanf("%d", &n) != EOF) {
		while(n--) {
			aux = (ELEMENT *) malloc(sizeof(ELEMENT));
			scanf("%d", &aux->value);

			insertVector(h, aux);
		}

		vectorHeapify(h);

		printHeap(h);

		while(aux = top(h)) {
			free(aux);
			pop(h);
		}
	}

	freeHeap(h);

	return 0;
}
