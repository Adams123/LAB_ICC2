#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define LEFT_CHILD(N) 2*N + 1
#define RIGHT_CHILD(N) 2*N + 2
#define PARENT(N) (N - 1) / 2
#define ROOT 0

#define MIN_HEAP lesser
#define MAX_HEAP greater

typedef struct {
	//int key;
	char value[20];
} ELEMENT;

void swap(ELEMENT **v, int i, int j) {
	ELEMENT *aux = v[i];
	v[i] = v[j];
	v[j] = aux;
}

int greater(ELEMENT *a, ELEMENT *b) {
	return strcmp(a->value, b->value) > 0;
}

void down(ELEMENT **v, int i, int n) {
	if(i < n) {
		int leftChild = LEFT_CHILD(i);
		int rightChild = RIGHT_CHILD(i);
		int change = i;

		if(leftChild < n && greater(v[leftChild], v[change]))
			change = leftChild;

		if(rightChild < n && greater(v[rightChild], v[change]))
			change = rightChild;

		if(change != i) {
			swap(v, i, change);
			down(v, change, n);
		}
	}
}

void up(ELEMENT **v, int i, int n) {
	if(i > 0 && i < n) {
		int parent = PARENT(i);

		if(greater(v[i], v[parent])) {
			swap(v, i, parent);
			up(v, parent, n);
		}
	}
}

void vectorHeapify(ELEMENT **v, int n) {
	int i;

	for(i = pow(2, floor(log2(n))) - 1; i >= 0; i--)
		down(v, i, n);
}

void ord(ELEMENT **v, int *n) {
	swap(v, --(*n), 0);
	down(v, 0, *n);
}

void heapsort(ELEMENT **v, int n) {
	vectorHeapify(v, n);

	while(n > 1)
		ord(v, &n);
}

void printVector(ELEMENT **v, int n) {
	int i;
	for (i = 0; i < n; i++)
		printf("%s ", v[i]->value);
	printf("\n");
}

int main() {
	ELEMENT **vector;
	ELEMENT *aux;
	int n, i;

	while(scanf("%d", &n) != EOF) {
		vector = (ELEMENT **) malloc(sizeof(ELEMENT *) * n);

		for(i = 0; i < n; i++) {
			vector[i] = (ELEMENT *) malloc(sizeof(ELEMENT));
			scanf("%s", vector[i]->value);
		}

		heapsort(vector, n);

		printVector(vector, n);

		for(i = 0; i < n; i++)
			free(vector[i]);
		free(vector);
	}

	return 0;
}
