#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define LEFT_CHILD(N) 2*N + 1
#define RIGHT_CHILD(N) 2*N + 2
#define PARENT(N) (N - 1) / 2
#define ROOT 0

#define MIN_HEAP lesser
#define MAX_HEAP greater

typedef struct {
	int priority;
	int counter;
	char name[20];
} PROCESS;

typedef struct {
	PROCESS **content;
	int size;
	int (*compare)(PROCESS *, PROCESS *);
} HEAP;

typedef struct node {
	PROCESS *p;
	struct node *next;
} NODE;

typedef struct {
	NODE *start;
	NODE *end;
	int size;
	int maxSize;
} QUEUE;

QUEUE *createQueue(int maxSize) {
	QUEUE *res = (QUEUE *) malloc(sizeof(QUEUE));
	res->start = NULL;
	res->end = NULL;
	res->maxSize = maxSize;
	res->size = 0;
	return res;
}

unsigned char fullQueue(QUEUE *q) {
	return q->size == q->maxSize;
}

unsigned char insertQueue(QUEUE *q, PROCESS *p) {
	if(q->size < q->maxSize) {
		NODE *insert = (NODE *) malloc(sizeof(NODE));
		insert->p = p;
		insert->next = NULL;

		if(q->start == NULL)
			q->start = q->end = insert;
		else
			q->end = q->end->next = insert;

		q->size++;

		return 1;
	}

	return 0;
}

PROCESS *removeQueue(QUEUE *q) {
	if(q->start != NULL) {
		PROCESS *res = q->start->p;

		if(q->size == 1)
			q->start = q->end = NULL;
		else
			q->start = q->start->next;

		q->size--;
		return res;
	}

	return NULL;
}

void swap(PROCESS **v, int i, int j) {
	PROCESS *aux = v[i];
	v[i] = v[j];
	v[j] = aux;
}

int lesser(PROCESS *a, PROCESS *b) {
	return a->priority < b->priority;
}

HEAP *createHeap(int compare(PROCESS *, PROCESS *)) {
	HEAP *res = (HEAP *) malloc(sizeof(HEAP));
	res->size = 0;
	res->content = NULL;
	res->compare = compare;

	return res;
}

void down(HEAP *heap, int i) {
	if(i < heap->size) {
		int leftChild = LEFT_CHILD(i);
		int rightChild = RIGHT_CHILD(i);
		int change = i;

		if(leftChild < heap->size && heap->compare(heap->content[leftChild], heap->content[change]))
			change = leftChild;

		if(rightChild < heap->size && heap->compare(heap->content[rightChild], heap->content[change]))
			change = rightChild;

		if(change != i) {
			swap(heap->content, i, change);
			down(heap, change);
		}
	}
}

void up(HEAP *heap, int i) {
	if(i > 0 && i < heap->size) {
		int parent = PARENT(i);

		if(heap->compare(heap->content[i], heap->content[parent])) {
			swap(heap->content, i, parent);
			up(heap, parent);
		}
	}
}

void insertHeap(HEAP *heap, PROCESS *process) {
    heap->content = (PROCESS **) realloc(heap->content, sizeof(PROCESS *) * (++(heap->size)));
    heap->content[heap->size - 1] = process;
    up(heap, heap->size - 1);
}

PROCESS *topHeap(HEAP *heap) {
    if(heap->size > 0)
        return heap->content[ROOT];

    return NULL;
}

void popHeap(HEAP *heap) {
	if(heap->size > 0) {
		swap(heap->content, ROOT, heap->size - 1);
		heap->content = (PROCESS **) realloc(heap->content, sizeof(PROCESS *)*(--(heap->size)));

		down(heap, ROOT);
	}
}

void freeHeap(HEAP *heap) {
    free(heap->content);
    free(heap);
}

int main() {
	HEAP *h = createHeap(MIN_HEAP);

    int N;
	scanf("%d", &N);
	QUEUE *q = createQueue(N);
	
    PROCESS *aux = NULL;

	while((aux = (PROCESS *)malloc(sizeof(PROCESS))) != NULL && scanf("%d %d %s", &aux->priority, &aux->counter, aux->name) != EOF && aux->priority > 0) {
		insertHeap(h, aux);
		aux = NULL;
	}
	if(aux != NULL) free(aux);

	while(h->size > 0 || q->size > 0) {
		if(!fullQueue(q) && h->size > 0) {
			aux = topHeap(h);
			popHeap(h);

			printf("Executando: %s %d\n", aux->name, aux->priority);

			insertQueue(q, aux);
		} else {
			aux = removeQueue(q);
			aux->counter--;

			if(h->size > 0 && aux->counter > 0)
				aux->priority = (topHeap(h)->priority + 1) <= 20 ? (topHeap(h)->priority + 1) : 20;

			if(aux->counter > 0) {
				printf("Saiu: %s %d\n", aux->name, aux->priority);
				insertHeap(h, aux);
			} else {
				printf("Executou: %s %d\n", aux->name, aux->priority);
				free(aux);
			}
		}
	}

	freeHeap(h);

	return 0;
}
